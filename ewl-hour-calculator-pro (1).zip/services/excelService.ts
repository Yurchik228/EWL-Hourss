
import * as XLSX from 'xlsx';
import { SheetAnalysis, DayPair, Segment, NameColumns, CalculationResult, DayRange, CalculationSummary, CalculationStats } from '../types';

export class ExcelService {
  static normalizeText(v: any): string {
    if (v === null || v === undefined) return "";
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    return String(v)
      .replace(/[\u00A0\u1680​\u180e\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]/g, ' ')
      .trim()
      .replace(/\s+/g, ' ');
  }

  static parseHours(v: any): number {
    if (v === null || v === undefined || v === "") return 0;
    if (typeof v === "number" && Number.isFinite(v)) return v;
    
    let s = this.normalizeText(v).replace(",", ".").toLowerCase();
    const inactiveMarkers = ["off", "nu", "nb", "—", "x", "urlop", "chorobowe", "l4", "nż", "nz", "delegacja", "nn"];
    if (inactiveMarkers.some(m => s === m)) return 0;
    
    const match = s.match(/(\d+(\.\d+)?)/);
    if (match) {
      const val = parseFloat(match[1]);
      return isNaN(val) ? 0 : val;
    }
    return 0;
  }

  static getAbsenceType(v: any): string | null {
    if (v === null || v === undefined || v === "") return null;
    const s = this.normalizeText(v).toLowerCase();
    const codes = ["nn", "nu", "l4", "off", "urlop", "chorobowe", "nb", "nż", "nz", "delegacja"];
    for (const code of codes) {
      if (s === code) return code.toUpperCase();
    }
    return null;
  }

  static getDayFromCell(v: any): number | null {
    if (v === null || v === undefined || v === "") return null;
    if (v instanceof Date) return v.getDate();
    if (typeof v === "number" && Number.isFinite(v)) {
      const n = Math.floor(v);
      return (n >= 1 && n <= 31) ? n : null;
    }
    const s = String(v).trim();
    const match = s.match(/^0?([1-9]|[12][0-9]|3[01])(\D|$)/);
    if (match) return parseInt(match[1], 10);
    return null;
  }

  static getShiftToken(v: any): "6-18" | "18-6" | "pair" | "" {
    const s = String(v ?? "").toLowerCase().replace(/\s+/g, '');
    if (!s) return "";
    const has6 = s.includes('6');
    const has18 = s.includes('18');
    if (has6 && has18) return "pair";
    if (has6) return "6-18";
    if (has18) return "18-6";
    return "";
  }

  static sheetToGrid(ws: XLSX.WorkSheet): any[][] {
    const rawGrid = XLSX.utils.sheet_to_json(ws, { 
      header: 1, 
      defval: "", 
      blankrows: true 
    }) as any[][];

    if (rawGrid.length === 0) return [];

    let maxWidth = 0;
    rawGrid.forEach(row => { if (Array.isArray(row) && row.length > maxWidth) maxWidth = row.length; });
    if (maxWidth < 185) maxWidth = 185;

    const grid = rawGrid.map(row => {
      const newRow = Array.isArray(row) ? [...row] : [];
      while (newRow.length < maxWidth) newRow.push("");
      return newRow;
    });

    const merges = ws["!merges"] || [];
    for (const m of merges) {
      const master = grid[m.s.r]?.[m.s.c];
      if (master === "" || master === undefined) continue;
      for (let rr = m.s.r; rr <= m.e.r; rr++) {
        if (!grid[rr]) continue;
        for (let cc = m.s.c; cc <= m.e.c; cc++) {
          if (rr === m.s.r && cc === m.s.c) continue;
          if (grid[rr][cc] === "" || grid[rr][cc] === undefined) {
            grid[rr][cc] = master;
          }
        }
      }
    }
    return grid;
  }

  static findShiftRow(grid: any[][]): { r: number; starts: number[] } | null {
    let best = null;
    const limit = Math.min(grid.length, 100); 
    for (let r = 0; r < limit; r++) {
      const row = grid[r] || [];
      let starts: number[] = [];
      for (let c = 0; c < row.length - 1; c++) {
        const a = this.getShiftToken(row[c]);
        const b = this.getShiftToken(row[c+1]);
        if ((a === "6-18" && b === "18-6") || a === "pair" || b === "pair") {
          starts.push(c);
          c++;
        }
      }
      if (starts.length >= 2) {
        if (!best || starts.length > best.starts.length) {
          best = { r, starts };
        }
      }
    }
    return best;
  }

  static buildDayPairs(grid: any[][], shiftRow: number, starts: number[], dayRowManual: number | null): { pairs: DayPair[]; segments: Segment[] } | null {
    const pairs: DayPair[] = [];
    for (const startC of starts) {
      let day: number | null = null;
      if (dayRowManual !== null) {
        day = this.getDayFromCell(grid[dayRowManual]?.[startC]) ?? this.getDayFromCell(grid[dayRowManual]?.[startC+1]);
      } else {
        for (let rr = shiftRow - 1; rr >= Math.max(0, shiftRow - 12); rr--) {
          day = this.getDayFromCell(grid[rr]?.[startC]) ?? this.getDayFromCell(grid[rr]?.[startC+1]);
          if (day !== null) break;
        }
      }
      if (day !== null) {
        pairs.push({ day, colA: startC, colB: startC + 1 });
      }
    }
    if (pairs.length === 0) return null;
    pairs.sort((a, b) => a.colA - b.colA);
    let currentSeg = 1;
    pairs[0].seg = currentSeg;
    for (let i = 1; i < pairs.length; i++) {
      if (pairs[i].day < pairs[i-1].day) currentSeg++;
      pairs[i].seg = currentSeg;
    }
    const segments: Segment[] = [];
    for (let s = 1; s <= currentSeg; s++) {
      const ps = pairs.filter(p => p.seg === s);
      if (ps.length === 0) continue;
      segments.push({
        seg: s,
        dayMin: Math.min(...ps.map(p => p.day)),
        dayMax: Math.max(...ps.map(p => p.day)),
        countPairs: ps.length
      });
    }
    return { pairs, segments };
  }

  static analyzeSheet(workbook: XLSX.WorkBook, sheetName: string, fileName: string, manualShiftRow?: number, manualDayRow?: number): SheetAnalysis {
    const ws = workbook.Sheets[sheetName];
    if (!ws) return { ok: false, err: "Brak arkusza", sheetName, fileName };
    const grid = this.sheetToGrid(ws);
    if (grid.length === 0) return { ok: false, err: "Arkusz jest pusty", sheetName, fileName };
    let shiftInfo = null;
    if (manualShiftRow) {
      const r = manualShiftRow - 1;
      const row = grid[r] || [];
      let starts: number[] = [];
      for (let c = 0; c < row.length - 1; c++) {
        const a = this.getShiftToken(row[c]);
        const b = this.getShiftToken(row[c+1]);
        if (a || b) { starts.push(c); c++; }
      }
      shiftInfo = { r, starts };
    } else {
      shiftInfo = this.findShiftRow(grid);
    }
    if (!shiftInfo || shiftInfo.starts.length === 0) return { ok: false, err: "Nie znaleziono nagłówków 6-18 / 18-6", sheetName, fileName };
    const dp = this.buildDayPairs(grid, shiftInfo.r, shiftInfo.starts, manualDayRow ? manualDayRow - 1 : null);
    if (!dp) return { ok: false, err: "Nie znaleziono numerów dni nad zmianami", sheetName, fileName };
    let cols = { colLine: 0, colLast: 1, colFirst: 2 };
    const scanStart = Math.max(0, shiftInfo.r - 10);
    const scanEnd = Math.min(grid.length - 1, shiftInfo.r + 5);
    for (let r = scanStart; r <= scanEnd; r++) {
      const row = (grid[r] || []).map(v => String(v || "").toLowerCase());
      const idxL = row.findIndex(x => x.includes("linia") || x.includes("station") || x.includes("stanowisko"));
      const idxN = row.findIndex(x => x.includes("nazwisko") || x.includes("surname") || x.includes("family"));
      const idxI = row.findIndex(x => x.includes("imię") || x.includes("imie") || x.includes("name") || x.includes("first"));
      if (idxN !== -1 || idxI !== -1) {
        if (idxL !== -1) cols.colLine = idxL;
        if (idxN !== -1) cols.colLast = idxN;
        if (idxI !== -1) cols.colFirst = idxI;
        break;
      }
    }
    return { 
      ok: true, sheetName, fileName, grid, shiftRow: shiftInfo.r, 
      nameCols: cols, dataStartRow: shiftInfo.r + 1, 
      pairs: dp.pairs, segments: dp.segments 
    };
  }

  static calculate(
    analyses: Map<string, SheetAnalysis>,
    selectedSheets: Set<string>,
    sheetSegments: Map<string, number>,
    dayRange: DayRange,
    includeSheet: boolean,
    ignoreLine: boolean = true,
    minHours: number = 0.1,
    filterInactive: boolean = true
  ): CalculationSummary {
    const resultsMap = new Map<string, CalculationResult>();
    const sheetDailyTotals: Record<string, Record<number, number>> = {};
    const stats: CalculationStats = { 
      totalHours: 0, 
      totalPeople: 0, 
      skippedRows: 0, 
      skippedReasons: { emptyName: 0, zeroHours: 0, invalidFormat: 0, inactive: 0 } 
    };

    const terminationKeywords = ["suma", "razem", "total", "uvolen", "zwolnion", "koniec", "fired"];

    for (const key of Array.from(selectedSheets)) {
      const a = analyses.get(key);
      if (!a || !a.ok || !a.grid) continue;
      
      const sheetDisplayName = `${a.fileName} | ${a.sheetName}`;
      if (!sheetDailyTotals[sheetDisplayName]) sheetDailyTotals[sheetDisplayName] = {};
      
      const seg = sheetSegments.get(key) || 1;
      const allSegmentPairs = (a.pairs || []).filter(p => p.seg === seg);
      const activePairsInRange = allSegmentPairs.filter(p => p.day >= dayRange.from && p.day <= dayRange.to);
      const { colLine, colFirst, colLast } = a.nameCols!;

      for (let r = a.dataStartRow!; r < a.grid.length; r++) {
        const row = a.grid[r];
        if (!row) continue;
        const imie = this.normalizeText(row[colFirst]);
        const nazw = this.normalizeText(row[colLast]);
        const linia = this.normalizeText(row[colLine]);
        if (!imie && !nazw) continue;

        const fullNameLower = (imie + " " + nazw + " " + linia).toLowerCase();
        if (terminationKeywords.some(key => fullNameLower.includes(key))) continue;

        let rowSum = 0;
        let daysWorkedCount = 0;
        const daily: Record<number, number> = {};
        const absences: Record<string, number> = {};
        
        for (const p of activePairsInRange) {
          const hA = this.parseHours(row[p.colA]);
          const hB = this.parseHours(row[p.colB]);
          const h = hA + hB;

          if (h > 0) {
            rowSum += h;
            daysWorkedCount++;
            daily[p.day] = (daily[p.day] || 0) + h;
          } else {
            const codeA = this.getAbsenceType(row[p.colA]);
            const codeB = this.getAbsenceType(row[p.colB]);
            const code = codeA || codeB;
            if (code) {
              absences[code] = (absences[code] || 0) + 1;
            }
          }
        }

        if (rowSum < minHours && Object.keys(absences).length === 0 && filterInactive && daysWorkedCount === 0) {
          continue;
        }

        // Result Key logic
        let resKey = `${imie}|${nazw}`.toLowerCase();
        if (!ignoreLine) resKey = `${linia}|${resKey}`;
        // If we aggregate from multiple files, we usually want to merge people with same names
        // If includeSheet is TRUE, we separate them by file/sheet
        if (includeSheet) resKey = `${key}|${resKey}`;

        if (!resultsMap.has(resKey)) {
          resultsMap.set(resKey, { 
            Sheet: sheetDisplayName, Linia: linia, Imie: imie, Nazwisko: nazw, 
            Razem: 0, DailyBreakdown: {}, AbsenceBreakdown: {} 
          });
        }
        const res = resultsMap.get(resKey)!;
        res.Razem += rowSum;
        stats.totalHours += rowSum;
        
        for (const [d, h] of Object.entries(daily)) {
          const dN = parseInt(d);
          res.DailyBreakdown[dN] = (res.DailyBreakdown[dN] || 0) + h;
          sheetDailyTotals[sheetDisplayName][dN] = (sheetDailyTotals[sheetDisplayName][dN] || 0) + h;
        }

        for (const [code, count] of Object.entries(absences)) {
          res.AbsenceBreakdown[code] = (res.AbsenceBreakdown[code] || 0) + count;
        }
      }
    }
    const results = Array.from(resultsMap.values()).sort((a, b) => a.Nazwisko.localeCompare(b.Nazwisko));
    stats.totalPeople = results.length;
    return { results, stats, sheetDailyTotals };
  }
}
