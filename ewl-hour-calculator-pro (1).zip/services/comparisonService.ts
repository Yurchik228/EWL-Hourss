
import { CalculationResult, MasterRecord, ComparisonItem } from '../types';

export class ComparisonService {
  /**
   * Cleans names from emojis, special characters and double spaces
   */
  static cleanName(name: string): string {
    return name
      .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '') // strip emojis
      .replace(/[^\w\s\u0400-\u04FF]/g, ' ') // replace non-alphanumeric (keep cyrillic and latin)
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  /**
   * Calculates similarity between two names (0.0 - 1.0)
   */
  static getSimilarity(s1: string, s2: string): number {
    const n1 = this.cleanName(s1);
    const n2 = this.cleanName(s2);
    
    if (!n1 || !n2) return 0;
    if (n1 === n2) return 1.0;

    const words1 = n1.split(/\s+/);
    const words2 = n2.split(/\s+/);

    // 1. Subset check (order independence)
    const isSubset = words1.every(w => words2.includes(w)) || words2.every(w => words1.includes(w));
    if (isSubset) return 0.95;

    // 2. Levenshtein Distance
    let longer = n1;
    let shorter = n2;
    if (n1.length < n2.length) {
      longer = n2;
      shorter = n1;
    }
    const longerLength = longer.length;
    if (longerLength === 0) return 1.0;
    
    const levSim = (longerLength - this.editDistance(longer, shorter)) / longerLength;
    
    // 3. Jaccard-like Overlap
    const set1 = new Set(words1);
    const set2 = new Set(words2);
    const intersection = new Set([...set1].filter(x => set2.has(x)));
    const overlapSim = intersection.size / Math.max(set1.size, set2.size);
    
    return Math.max(levSim, overlapSim);
  }

  private static editDistance(s1: string, s2: string): number {
    const costs = [];
    for (let i = 0; i <= s1.length; i++) {
      let lastValue = i;
      for (let j = 0; j <= s2.length; j++) {
        if (i === 0) costs[j] = j;
        else if (j > 0) {
          let newValue = costs[j - 1];
          if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
            newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
          }
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
      if (i > 0) costs[s2.length] = lastValue;
    }
    return costs[s2.length];
  }

  /**
   * Parses text data with duplicate aggregation and emoji cleaning
   */
  static parseTextData(text: string): MasterRecord[] {
    if (!text || !text.trim()) return [];
    
    const lines = text.split(/\r?\n/).filter(l => l.trim() !== "");
    const records: MasterRecord[] = [];

    for (const line of lines) {
      const parts = line.split("\t"); 
      if (parts.length < 2) continue;

      let hours = 0;
      let nameParts: string[] = [];

      const numericParts = parts
        .map(p => ({ val: parseFloat(p.trim().replace(",", ".")), original: p.trim() }))
        .filter(p => !isNaN(p.val) && p.val !== 0);

      if (numericParts.length > 0) {
        const potentialHours = numericParts.find(p => p.val !== 31.4 && p.val !== 31.40);
        hours = potentialHours ? potentialHours.val : numericParts[0].val;
      }

      for (const part of parts) {
        const p = part.trim();
        const isNum = !isNaN(parseFloat(p.replace(",", ".")));
        if (!isNum && p.length > 1) {
          const low = p.toLowerCase();
          if (!["imię", "nazwisko", "linia", "imię i nazwisko", "razem", "suma"].includes(low)) {
            nameParts.push(p);
          }
        }
      }

      if (nameParts.length >= 1) {
        records.push({
          fullName: nameParts.join(" "),
          hours: hours
        });
      }
    }

    const aggregated = new Map<string, number>();
    records.forEach(r => {
      const key = this.cleanName(r.fullName);
      aggregated.set(key, (aggregated.get(key) || 0) + r.hours);
    });

    return Array.from(aggregated.entries()).map(([name, hrs]) => ({
      fullName: name,
      hours: hrs
    }));
  }

  /**
   * Core logic for comparing system report with master files
   */
  static compareData(systemRecords: MasterRecord[], masterRecords: MasterRecord[]): ComparisonItem[] {
    const results: ComparisonItem[] = [];
    const usedMasterIndices = new Set<number>();

    for (const sysPerson of systemRecords) {
      let bestMasterIdx = -1;
      let bestSim = 0;

      masterRecords.forEach((m, idx) => {
        const sim = this.getSimilarity(sysPerson.fullName, m.fullName);
        if (sim > bestSim) {
          bestSim = sim;
          bestMasterIdx = idx;
        }
      });

      if (bestSim >= 0.6) {
        const m = masterRecords[bestMasterIdx];
        usedMasterIndices.add(bestMasterIdx);
        const diff = sysPerson.hours - m.hours;
        
        results.push({
          name: sysPerson.fullName,
          systemHours: sysPerson.hours,
          masterHours: m.hours,
          diff: diff,
          status: Math.abs(diff) < 0.05 ? 'ok' : 'mismatch',
          similarity: bestSim
        });
      } else {
        results.push({
          name: sysPerson.fullName,
          systemHours: sysPerson.hours,
          masterHours: 0,
          diff: sysPerson.hours,
          status: 'missing_master',
          similarity: 0
        });
      }
    }

    masterRecords.forEach((m, idx) => {
      if (!usedMasterIndices.has(idx)) {
        results.push({
          name: m.fullName,
          systemHours: 0,
          masterHours: m.hours,
          diff: -m.hours,
          status: 'missing_system',
          similarity: 0
        });
      }
    });

    return results.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
  }
}
